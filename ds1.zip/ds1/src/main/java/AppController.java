public class AppController {

    private static final int LIST_CAPACITY = 5;

    private ArrayList<Student> _list;

    public ArrayList<Student> list() {
        return _list;
    }

    public void setList(ArrayList<Student> newList) {
        this._list = newList;
    }

    public AppController() {
        this.setList(new ArrayList<Student>(AppController.LIST_CAPACITY));
    }

    public void run() {

        AppView.outputLine("<<< ����Ʈ ��� Ȯ�� ���α׷��� �����մϴ�. >>>");

        this.showMenu();
        MainMenu selectedMenuValue = this.selectMenu();

        while (selectedMenuValue != MainMenu.EndOfRun) { //END_OF_RUN �Ͻ� ����
            switch (selectedMenuValue) {
                case DoesContain:
                    this.doesContain();
                    break;
                case ElementAt:
                    this.elementAt();
                    break;
                case First:
                    this.first();
                    break;
                case Last:
                    this.last();
                    break;
                case OrderOf:
                    this.orderOf();
                    break;
                case AddTo:
                    this.AddTo();
                    break;
                case AddToFirst:
                    this.addToFirst();
                    break;
                case AddToLast:
                    this.addToLast();
                    break;
                case Add:
                    this.add();
                    break;
                case RemoveFrom:
                    this.removeFrom();
                    break;
                case RemoveFirst:
                    this.removeFirst();
                    break;
                case RemoveLast:
                    this.removeLast();
                    break;
                case RemoveAny:
                    this.removeAny();
                    break;
                case ReplaceAt:
                    this.replaceAt();
                    break;
                default:
                    break;

            }
            selectedMenuValue = this.selectMenu();

        }
        this.showStatics();

        AppView.outputLine("");
        AppView.outputLine("<<< ����Ʈ ��� Ȯ�� ���α׷��� �����մϴ�. >>> ");

    }

    private void replaceAt() {
        AppView.outputLine("");
        AppView.outputLine("! replaceAt �۾��� �����մϴ�. : ");
    }

    private void removeAny() {
        AppView.outputLine("");
        AppView.outputLine("! RemoveAny �۾��� �����մϴ�. ");

    }

    private void removeLast() {
        AppView.outputLine("");
        AppView.outputLine("! RemoveLast �۾��� �����մϴ�. ");
    }

    private void removeFirst() {
        AppView.outputLine("");
        AppView.outputLine("! RemoveFirst �۾��� �����մϴ�. ");
    }

    private void removeFrom() {
        AppView.outputLine("");
        AppView.outputLine("! RemoveFrom �۾��� �����մϴ�. : ");
    }

    private void addToLast() {
        AppView.outputLine("");
        AppView.outputLine("! AddToLast �۾��� �����մϴ�. ");
    }

    private void add() {
        AppView.outputLine("");
        AppView.outputLine("! add �۾��� �����մϴ�. : ");

    }

    private void addToFirst() {
        AppView.outputLine("");
        AppView.outputLine("! addToFirst �۾��� �����մϴ�.: ");
    }

    private void AddTo() {
        AppView.outputLine("");
        AppView.outputLine("! AddTo �۾��� �����մϴ�. : ");
    }

    private void orderOf() {
        AppView.outputLine("");
        AppView.outputLine("! OrderOf �۾��� �����մϴ�. : ");
    }

    private void last() {
        AppView.outputLine("");
        AppView.outputLine("! Last �۾��� ���� �մϴ�. : ");
    }

    private void first() {
        AppView.outputLine("");
        AppView.outputLine("! First �۾��� �����մϴ�. : ");
    }

    private void elementAt() {
        AppView.outputLine("");
        AppView.outputLine("! ElementAt �۾��� �����մϴ�. : ");
    }

    private void doesContain() {
        AppView.outputLine("");
        AppView.outputLine("! DoesContain �۾��� �����մϴ�. ");
    }

    private void showMenu() {
        AppView.outputLine("> �ؾ� �� �۾��� ��ȣ�� �����ؾ� �մϴ�. ");
        AppView.outputLine("DoesContain = 1, ElemntAt = 2, First = 3, Last = 4, OrderOf = 5 ");
        AppView.outputLine("AddTo = 6, AddFirst = 7, AddToLast = 8, Add = 9, ");
        AppView.outputLine("RemoveFrom = 10, RemoveFisrt = 11, RemoveLast = 12, RemoveAny = 13, RelpaceAt = 14, END_OF_RUN = 99 ");
        AppView.output("�۾� ��ȣ�� �Է� �ϼ���: "); //todo

    }


    private void showStatics() {
        //todo
    }


    private MainMenu selectMenu() {//�޴��� �����մϴ�.
        AppView.outputLine("");
        this.showList();
        this.showMenu();

        int selectedMenuNumber = AppView.inputInteger();
        MainMenu selectedMenuValue = MainMenu.value(selectedMenuNumber);

        return selectedMenuValue;

    }

    private void showList() {
        //todo
    }

    private int inputScore() {
        int score;
        while (true) {
            AppView.output("? ������ �Է�")
        }

    }
}
