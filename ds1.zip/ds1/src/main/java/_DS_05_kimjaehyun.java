public class _DS_05_kimjaehyun {

    public static void main(String[] args) {
        AppController appController = new AppController();
        appController.run();
    }


}
